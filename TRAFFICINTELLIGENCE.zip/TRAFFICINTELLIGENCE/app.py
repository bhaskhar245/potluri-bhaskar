# app.py
from flask import Flask, render_template, request, redirect, url_for
import numpy as np
import pickle
from datetime import datetime

app = Flask(__name__)

# Load the trained model
with open('model/model.pkl', 'rb') as f:
    model = pickle.load(f)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        try:
            # Extract and parse inputs
            temp = float(request.form['temp'])
            rain = float(request.form['rain'])
            snow = float(request.form['snow'])
            date_str = request.form['date']  # e.g., 02-10-2012
            hour = int(request.form['hours'])
            minute = int(request.form['minutes'])
            second = int(request.form['seconds'])

            # Parse date into day, month, year
            parsed_date = datetime.strptime(date_str, "%d-%m-%Y")
            day = parsed_date.day
            month = parsed_date.month
            year = parsed_date.year

            # Prepare input features
            features = np.array([[temp, rain, snow, day, month, year, hour, minute, second, 1.0]])  # 10 features
            prediction = model.predict(features)[0]

            result = f"Predicted Traffic Volume: {int(prediction)} vehicles"
            return redirect(url_for('result', prediction=result))

        except Exception as e:
            return f"Error: {e}"

    return render_template('index.html')

@app.route('/result')
def result():
    prediction = request.args.get('prediction')
    return render_template('result.html', prediction=prediction)

if __name__ == '__main__':
    app.run(debug=True)
