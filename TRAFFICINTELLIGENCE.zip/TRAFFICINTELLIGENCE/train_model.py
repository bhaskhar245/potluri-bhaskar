# train_model.py
import numpy as np
from sklearn.ensemble import RandomForestRegressor
import pickle
import os

# Generate dummy training data (100 samples, 10 features)
X = np.random.rand(100, 10)  # Features: temp, rain, snow, day, month, year, hour, min, sec, 1 (dummy)
y = np.random.randint(100, 1000, size=100)

# Train model
model = RandomForestRegressor()
model.fit(X, y)

# Save model to model/model.pkl
os.makedirs("model", exist_ok=True)
with open('model/model.pkl', 'wb') as f:
    pickle.dump(model, f)

print("✅ Model trained and saved as model/model.pkl")
